//
// Handler thread observer interface
//
package com.adam.app.demoset.myHandlerThread;

public interface HandlerObserver {
    void updateTaskInfo();
}
