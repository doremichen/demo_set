package com.adam.app.demoset.notification;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.adam.app.demoset.R;

public class NotifyResultAct extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notify_result);
    }
}
