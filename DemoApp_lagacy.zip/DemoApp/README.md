# demo_set
This DemoSet would contain some example app. It use the list style to present. 
The demo item is as the following at the current moment.
1. Alarm
2. JNI method invacation and callback
3. Database access
4. Bluetooth function
5. Camera
6. Video recording
7. ScheduledExecutor service
8. WorkManager
9. Remote and local Service communication
10. Floating dialog
11. ...
![image](https://github.com/doremichen/demo_set/blob/master/Screenshot_DemoSet.jpg)
